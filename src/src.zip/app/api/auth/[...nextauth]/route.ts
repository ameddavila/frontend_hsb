import NextAuth, { NextAuthOptions, User, Session } from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";
import axios from "axios";
import { JWT } from "next-auth/jwt";

// 🔹 Definir `CustomUser` con los valores del token
interface CustomUser extends User {
  id: string;
  roleId: number;
  roleName: string;
}

// 🔹 Función para refrescar el accessToken cuando expira
async function refreshAccessToken(token: JWT): Promise<JWT> {
  try {
    const response = await axios.post(
      `${process.env.NEXT_PUBLIC_API_URL}/auth/refresh`,
      {},
      { withCredentials: true } // 🔹 Envía cookies automáticamente
    );

    if (!response.data) {
      throw new Error("No se recibió un nuevo accessToken");
    }

    return {
      ...token,
      accessToken: response.data.accessToken,
      accessTokenExpires: response.data.exp * 1000, // Convertir segundos a milisegundos
    };
  } catch (error) {
    console.error("Error refrescando token:", error);
    return { ...token, error: "RefreshTokenError" };
  }
}

// 🔹 Configuración de NextAuth
const authOptions: NextAuthOptions = {
  providers: [
    CredentialsProvider({
      name: "Credentials",
      credentials: {
        usernameOrEmail: { label: "Usuario o Email", type: "text" },
        password: { label: "Contraseña", type: "password" },
      },
      async authorize(credentials): Promise<CustomUser | null> {
        try {
          if (!credentials) throw new Error("Credenciales no proporcionadas");

          const response = await axios.post(
            `${process.env.NEXT_PUBLIC_API_URL}/auth/login`,
            {
              usernameOrEmail: credentials.usernameOrEmail,
              password: credentials.password,
            },
            { withCredentials: true }
          );

          const { accessToken } = response.data;
          if (!accessToken) throw new Error("Error en la autenticación");

          const decodedToken = JSON.parse(atob(accessToken.split(".")[1])); // 🔹 Decodificar el JWT

          return {
            id: decodedToken.userId,
            roleId: decodedToken.roleId,
            roleName: decodedToken.roleName,
          };
        } catch (error) {
          console.error("Error en autenticación:", error);
          return null;
        }
      },
    }),
  ],
  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        return {
          ...token,
          id: user.id,
          roleId: user.roleId,
          roleName: user.roleName,
          accessTokenExpires: Date.now() + 15 * 60 * 1000, // 🔹 Expira en 15 min
        };
      }

      // 🔹 Verificar si el token ha expirado
      if (Date.now() < (token.accessTokenExpires as number)) {
        return token;
      }

      // 🔹 Intentar renovar el token si está expirado
      return await refreshAccessToken(token);
    },
    async session({ session, token }: { session: Session; token: JWT }) {
      session.user = {
        id: token.id as string,
        roleId: token.roleId as number,
        roleName: token.roleName as string,
      };

      return session;
    },
  },
  pages: {
    signIn: "/login",
  },
  secret: process.env.NEXTAUTH_SECRET,
  session: { strategy: "jwt" },
};

const handler = NextAuth(authOptions);
export { handler as GET, handler as POST };
