"use client";
import { useSession } from "next-auth/react";

export default function DashboardPage() {
  const { data: session, status } = useSession();

  if (status === "loading") {
    return <div className="p-4 text-blue-500">Cargando...</div>;
  }

  if (status === "unauthenticated") {
    return (
      <div className="p-4 text-red-500">
        Acceso denegado. Debes iniciar sesión.
      </div>
    );
  }

  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold">
        Bienvenido, {session?.user?.role || "Usuario"}!
      </h1>
      <p className="mt-2 text-gray-700">Este es tu panel de control.</p>
    </div>
  );
}
